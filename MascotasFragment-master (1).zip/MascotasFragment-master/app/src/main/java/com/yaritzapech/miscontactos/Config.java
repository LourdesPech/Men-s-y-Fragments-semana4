package com.yaritzapech.miscontactos;



public class Config {
    public static final String EMAIL ="your-gmail-username";
    public static final String PASSWORD ="your-gmail-password";
}